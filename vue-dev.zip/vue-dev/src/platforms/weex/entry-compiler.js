export { compile } from 'weex/compiler/index'
